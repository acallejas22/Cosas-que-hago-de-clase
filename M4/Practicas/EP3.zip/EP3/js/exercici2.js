function order(){
    let aux1Input = document.getElementById('ex2_1Input').value;  //crea una variable con la que se accede al id del elemento
    let aux2Input = document.getElementById('ex2_2Input').value;
    let aux3Input = document.getElementById('ex2_3Input').value;
    let aux4Input = document.getElementById('ex2_4Input').value;

    const fruits = [aux1Input, aux2Input, aux3Input, aux4Input]; //se crea un array con las variables
 
    
    
if(isNaN(15/aux1Input) && isNaN(15/aux2Input)  && isNaN(15/aux3Input)  &&  isNaN(15/aux4Input) ){//condicion para ver si lo que se introduce es un string o un número
fruits.sort();                                                                                   // se ordena el array por alfabeto o de mayor a menor
document.getElementById('ej2label').innerHTML = fruits;                                          // se muestra el resultado
}
if(!isNaN(15/aux1Input) && !isNaN(15/aux2Input)  && !isNaN(15/aux3Input)  &&  !isNaN(15/aux4Input) ){//condicion por si no es un string lo que se introduce y son numeros de mas de una cifra
fruits.sort(function(a, b){return a - b});
document.getElementById('ej2label').innerHTML = fruits;
}



}

