let style = true; //se establece la variable para mostrar y deshacer la muestra del css


function changetext(){ //funcion para llamar al css del ejercicio 3
    let aux1Input = document.getElementById('ej3_1'); //crea una variable con la que se accede al id del elemento
    let aux2Input = document.getElementById('ej3_2');
    let aux3Input = document.getElementById('ej3_3');
    let aux4Input = document.getElementById('ej3_4');
    let aux5Input = document.getElementById('ej3_5');
    let aux6Input = document.getElementById('ej3_6');
    let aux7Input = document.getElementById('ej3_7');
    

    

    if(style){ //si la variable existe y se pulsa, pues se accede a la siguiente acción
        document.getElementById('ej3button').innerHTML = 'cambiar el texto';
        aux1Input.classList.add('ej_3_1'); //se le añade una clase al elemento
        aux2Input.classList.add('ej_3_2');
        aux3Input.classList.add('ej_3_3');
        aux4Input.classList.add('ej_3_4');
        aux5Input.classList.add('ej_3_5');
        aux6Input.classList.add('ej_3_6');
        aux7Input.classList.add('ej_3_7');

        style = false; //la variable pasa a ser false

    }else{
        document.getElementById('ej3button').innerHTML = 'reinicia';
        aux1Input.classList.remove('ej_3_1'); //se quita la clase al elemento
        aux2Input.classList.remove('ej_3_2');
        aux3Input.classList.remove('ej_3_3');
        aux4Input.classList.remove('ej_3_4');
        aux5Input.classList.remove('ej_3_5');
        aux6Input.classList.remove('ej_3_6');
        aux7Input.classList.remove('ej_3_7');

        style = true; //la variable pasa a ser true

    }

}