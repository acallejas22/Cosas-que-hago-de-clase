/** This function will hide or show the exercise clicked */
function changeExercise(pos) {
    /** V1 *
    document.getElementsByClassName('row')[0].style.display='none';
    document.getElementsByClassName('row')[1].style.display='none';
    document.getElementsByClassName('row')[2].style.display='none';
    document.getElementsByClassName('row')[3].style.display='none';
    // SHOW THE EXERCISE CLICKED 
    document.getElementsByClassName('row')[pos].style.display='flex';
    */

    /** V2 */
    for(let i=0; i<document.getElementsByClassName('row').length; i++) {
        //Changing exercise
        document.getElementsByClassName('row')[i].style.display='none';
        // Changing color+bg of navbar
        document.getElementsByTagName('a')[i].style.color='white';
        document.getElementsByTagName('a')[i].style.backgroundColor='#333';
    }
    // SHOW THE EXERCISE CLICKED 
    document.getElementsByClassName('row')[pos].style.display='flex';
    // Changing color+bg of navbar
    document.getElementsByTagName('a')[pos].style.color='black';
    document.getElementsByTagName('a')[pos].style.backgroundColor='#ddd';
    
}