function reverseInput(){
    let auxInput = document.getElementById('ex1Input').value;
    let auxResult = '';
    for(let i = auxInput.length - 1; i >= 0; i--){
        auxResult = auxResult + auxInput[i];


    }
    alert(auxResult);
}