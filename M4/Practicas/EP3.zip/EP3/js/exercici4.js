function mouseEncima() {
    var circulo = document.getElementById("circle");

    // Cuando estas dentro del circulo //
    circulo.addEventListener("mouseenter", function() {
    circulo.style.backgroundColor = "green";
    });
    // Cuando estas fuera del circulo //
    circulo.addEventListener("mouseleave", function() {
    circulo.style.backgroundColor = "transparent";
});
}