            /*Comment n-lines*/ 
        // FIRST VERSION: getElementById
        //document.getElementById("h1ID").innerHTML += " JS"; 
        // SECOND VERSION: getElementsByClassName 
        document.getElementsByClassName("h1Class")[0].innerHTML += 'JS';

        // THIRD VERSION: getElementsByTagName - FORMA NORMAL
       /* document.getElementsByTagName("p")[0].innerHTML = "Paragraph 0";
        document.getElementsByTagName("p")[1].innerHTML = "Paragraph 1";
        document.getElementsByTagName("p")[2].innerHTML = "Paragraph 2";
        document.getElementsByTagName("p")[3].innerHTML = "Paragraph 3";*/

        // THIRD VERSION: getElementsByTagName - FORMA "ITERATION FOR"
        // i++  // i = i+1  // i += 1
        /*for (let i = 0; i < document.getElementsByTagName("p").length; i++) {
            document.getElementsByTagName("p")[i].innerHTML = "Paragraph "+i;
        } */

        // THIRD VERSION: getElementsByTagName - FORMA "ITERATION WHILE"
        let i=0; // var i=0;  --> modificable
        const myPi = 3.1412341234; // Variable constant - not modificable
        while (i < document.getElementsByTagName("p").length) {
            document.getElementsByTagName("p")[i].innerHTML = "Paragraph "+i;
            i++;
        }

        
/*
 * Click me and I will change the color to pink of the letter
*/ 
function changeColorLetter() {
    document.getElementById('cclp').style.color='pink';
}

/**
 * Double click me and I will change my background to green
 */
function changeBC() {
    document.getElementsByClassName("cbcp")[0].style.backgroudColor="green"; 
}


/**
 * Put the mouse over me and I will disappear.
 */
function dissapearP() {
    document.getElementsByTagName('p')[6].style.display = "none";
}

/**
 * Put me the mouse and move down and I will change my size.
 */
function changeSize(elem) {
   elem.style.fontSize = "20px"; 
}

/**
 * Click me and I will get bigger, change my background to black,
 *  letter to white and content to "Hellow JS"
 */
function changeSizeBCLetter(elem) {
    elem.style.fontSize = "30px";
    elem.style.backgroundColor = "#000000";
    elem.style.color = "#ffffff";
    elem.innerHTML = "Hellow JS";
}

/**
 * 'Op1' - Put me the mouse and move down and I will change my size.
 * 'Op2' - Click me and I will get bigger, 
          change my background to black, letter to white and content to "Hellow JS
 */
function changeAll(elem, option) {
    //alert(option); // Pop-up
    if(option == 'Op1') { 
        // TODO 1
        changeSize(elem);
    }
    else { // 'Op2'
        // TODO 2
        changeSizeBCLetter(elem);
    }
}

/**
 * Calculator
 */
function calculate(valueButton) {
    //window.alert(valueButton); // alert(valueButton);
    // i++  // i += 1 // i = i+1
    if (valueButton == 'A') { 
        // If ANS is clicked we go here
        if (document.getElementById('myInput').value == '') {
            alert('WARNING: Sorry, there is nothing to calculate');
        } else {
            let result = eval(document.getElementById('myInput').value);
            document.getElementById('myInput').value = result;
        }
    } else if (valueButton == 'D') {
        // If D is clicked we delete the content in input
        document.getElementById('myInput').value = '';
    }
    else {
        // If a number or an operation is clicke we go here
        document.getElementById('myInput').value += valueButton;
    }

    
}